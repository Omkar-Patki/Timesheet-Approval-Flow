package com.excelr.utility;

public interface AppConstant {

	public static final String ID_NOT_FOUND_MESSAGE ="no employee id found";
	public static final String INAVLID_Data_EXCEPTION ="Invalid data exception";

	
}
